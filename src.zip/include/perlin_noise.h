#include "smooth_step.h"
#include "random_direction.h"
#include <Eigen/Core>

// Given a 3d position as a seed, compute a smooth procedural noise
// value: "Perlin Noise", also known as "Gradient noise".
//
// Inputs:
//   st  3D seed
// Returns a smooth value between (-1,1)
//
// expects: random_direction, smooth_step
float perlin_noise(Eigen::Vector3d st);
 /////////////////////////////////////////////////////////////////////////////

