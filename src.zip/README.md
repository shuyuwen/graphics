The project is built on assignment 3, Raytracing, combined with texture mapping and .obj file reading and visualizing from assignment 5.
Add new objects to original assignment 3 source code, box and cyclinder.
Add texture mapping functions to all the objects, triangle, sphere, box, cyclinder
Use the readOBJ.cpp from assignment 5 source code and use the V F matrix to set up a triangle mesh that can be processed using the original code from assignemnt 3
Add new function to generate .png file rather than .ppm file. A much more common image type with smaller file size and alpha channel included.
Set up all the objects in the scene with proper material cooefficient and texture and then generate the image using raytracing function.
Reproduce the work: copy the whole folder and simply run build\Release\raytracing.exe, it will generate the final image rgb.png.
Github link: https://github.com/327926791/csc418project